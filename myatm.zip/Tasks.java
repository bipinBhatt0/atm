package myAtmProject;

public class Tasks {

	private double initialBalance = 1000.00;

	public double getInitialBalance() {
		return initialBalance;
	}

	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}

	public double withdraw(double withdrawAmount) {
		double currBalance = this.initialBalance;
		double finalBalance = currBalance;

		if (withdrawAmount > currBalance) {
			System.out.println("Sorry insufficiant amount in your bank account: ");
		} else if (withdrawAmount > 500) {
			finalBalance = currBalance - (0.05 * withdrawAmount + withdrawAmount);
		} else {
			finalBalance = currBalance - withdrawAmount;
		}
		return finalBalance;
	}

	public double deposit(double depositAmount) {
		double currBalance = this.initialBalance;
		double finalBalance = currBalance;

		if (depositAmount < 0) {
			System.out.println("Sorry the amount can not be deposited: ");
		} else {
			finalBalance = currBalance + depositAmount;
		}
		return finalBalance;
	}

	public double checkBalance() {
		double currBalance = this.initialBalance;
		return currBalance;
	}

}
