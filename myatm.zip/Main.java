package myAtmProject;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		String customers[] = { "Chris", "Paul", "Mike", "John", "Mary" };
		int[] pin = { 1111, 2222, 3333, 4444, 5555 };

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the correct username: ");
		String inputName = scan.nextLine();

		Customer obj = new Customer();
		Tasks obj2 = new Tasks();
		boolean status = obj.verifyUser(customers, inputName);
		if (status == true) {
			System.out.println("Please enter the pin number: ");

			int inputPin = scan.nextInt();
			boolean checkPin = obj.verifyPin(pin, inputPin, customers, inputName);
			if (checkPin == true) {
				System.out.println("\t" + "\t" + "welcome");
				obj.hollowRectangle();

				System.out.println("Please choose option 1 or 2 or 3 for withdraw deposit and balance enquiry");
				int option = scan.nextInt();
				if (option == 1) {
					System.out.print("How much money you want to take out? ");
					double withDraw = scan.nextDouble();
					double finalBal = obj2.withdraw(withDraw);
					System.out.print("The final Balance in your account is: " + finalBal);
				} else if (option == 2) {

					System.out.print("How much money you want to depsoit? ");
					double depositAmount = scan.nextDouble();
					double finalBal = obj2.deposit(depositAmount);
					System.out.print("The final Balance in your account is: " + finalBal);

				} else if (option == 3) {
					double myBalance = obj2.checkBalance();
					System.out.println("The total available balance is: " + myBalance);
				} else {
					System.out.print("Sorry invalid choice! ");
				}
			} 
			else {
				System.out.println("The pin Number does not matches!!!");
			}
		} 
		else {
			System.out.println("Sorry you have entered the incorrect userName");
		}

	}

}
