package myAtmProject;

public class Customer {

//	private String name;
//	private int pin;
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public int getPin() {
//		return pin;
//	}
//
//	public void setPin(int pin) {
//		this.pin = pin;
//	}

	public boolean verifyUser(String[] customers, String userName) {
		boolean flag = true;
		for (String arrCustomer : customers) {
			if (arrCustomer.equals(userName)) {
				flag = true;
				break;
			} else {
				flag = false;
			}
		}
		return flag;
	}

	public boolean verifyPin(int[] pinArr, int pinNum, String customers[], String Name) {
		int temp = 0;
		boolean flag = true;
		for (int i = 0; i < customers.length; i++) {
			if (customers[i].equals(Name)) {
				temp = i;
			}
		}
		int pinNumber = pinArr[temp];
		if (pinNumber == pinNum) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	public void hollowRectangle() {
		int height = 10;
		int width = 40;
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				if (i == 0 || i == height - 1 || j == 0) {
					System.out.print("#");

				} else {
					System.out.print(" ");
					if (i == 3 && j == 5) {
						System.out.print("Bank of America");

					} else if ((j == width - 1 && i == 3) || (j == width - 1 && i == 4) || (j == width - 1 && i == 5)
							|| (j == width - 1 && i == 6)) {
						System.out.print(" ");
					} else if (j == width - 1) {
						System.out.print("#");
					}

					else if (i == 4 && j == 5) {
						System.out.print("1. withdraw: w");
					} else if (i == 5 && j == 5) {
						System.out.print("2. deposit: d");
					}

					else if (i == 6 && j == 5) {
						System.out.print("3. balance enquiry: b");
					}

				}

			}
			System.out.println();

		}
	}
}
